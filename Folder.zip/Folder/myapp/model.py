from  django.db import models
from django.db.models import Model

class Student(Model):
    student_id=models.AutoField(primary_key=True)
    student_name=models.CharField(max_length=10)
    student_address=models.CharField(max_length=100)
    student_gender=models.CharField(max_length=20,choices=(('male','male'),('female','female')),default='male')
    student_image=models.ImageField(upload_to='images',width_field=None,height_field=None,max_length=1000)
    #def __unicode__(self):
     #      return self.student_id 
    class Meta:
       # app_label="Student"
        db_table ='student'
class Laptop(Model):
    Laptop_id=models.AutoField(primary_key=True)
    laptop_brand=models.CharField(max_length=20,choices=(('Dell','Dell'),('HP','HP'),('Lenovo','Lenovo')),default='Dell')
    student=models.ForeignKey(Student,on_delete=models.CASCADE)
    
    class Meta:
           db_table ='laptop'
        