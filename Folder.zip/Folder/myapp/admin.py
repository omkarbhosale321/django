from django.contrib import admin
from .model import Student,Laptop
# Register your models here.
admin.site.site_header="Admin Zone"
class StudentAdmin(admin.ModelAdmin):
         list_display=['student_id','student_name','student_address','student_image']
admin.site.register(Student,StudentAdmin)

class LaptopAdmin(admin.ModelAdmin):
   
    search_fields=['student__student_id']
    def student_id(self,instance):
        return instance.student.student_id
    list_display=['Laptop_id','laptop_brand','student_id']
    list_filter=('laptop_brand','Laptop_id','student__student_id')
    def get_form(self,request,obj=None,**k):
        form=super(LaptopAdmin,self).get_form(request,obj,**k)
        form.base_fields['student'].label_from_instance=lambda obj: "%s"%(obj.student_id)
        return form
admin.site.register(Laptop,LaptopAdmin)
