from django.apps import AppConfig


class MyprojectConfig(AppConfig):
    name = 'myproject'
