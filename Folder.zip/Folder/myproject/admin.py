from django.contrib import admin
from .models import PersonDetails,Product,Product_Desc,UserCart,Orders,Order_Status,Promocode,PU,Otp,Online_Transaction
# Register your models here.
admin.site.register(PersonDetails)
admin.site.register(Product)
admin.site.register(Product_Desc)
admin.site.register(UserCart)
admin.site.register(Orders)
admin.site.register(Promocode)
admin.site.register(PU)
admin.site.register(Otp)

admin.site.register(Order_Status)

admin.site.register(Online_Transaction)

