from .import views
from django.urls import path,include
urlpatterns = [
    path('register',views.index,name="index"),
    path('save', views.save, name="index"),
    path('return',views.returnurl,name='return'),
    path('notify',views.notify,name='notify'),
    
    path('me', views.form, name="form"),
    path('login', views.login, name="login"),
    path('home', views.home, name="home"),
    path('nav', views.navigation, name="nav"),
    path('nav2', views.navigation2, name="nav2"),
    path('my', views.start, name="start"),
    path('view', views.view, name="view"),
    path('viewcart', views.viewcart, name="viewcart"),
    path('slide', views.slider, name="slide"),
    path('addcart/<int:id>',views.addcart,name="add"),
    path('savecart',views.savecart,name="save"),
    path('addorder/<id>',views.addorder,name="addorder"),
    path('saveorder',views.saveorder,name="saveorder"),
    path('logout',views.logout_view,name="logout"),
   path('email',views.email,name="email"),
   path('vieworders',views.vieworders,name="vieworders"),
   path('deletecart/<id>',views.deletecart,name="dc"),
   path('sms',views.sms,name='sms'),
   path('resendotp',views.resend,name='resend'),
   path('verifyotp',views.verifyotp,name='verify'),
  # path('verifyuser',views.otp,name='otp')
]
