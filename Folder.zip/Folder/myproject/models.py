from django.conf  import settings
from django.core.mail import send_mail

from django.db import models
from django.contrib.auth.models import User
from unittest.util import _MAX_LENGTH
from itertools import product
from django.dispatch import receiver
from django.db.models.signals import  post_save
class Otp(models.Model):
    id=models.AutoField(primary_key=True)
    code=models.BinaryField(max_length=100)
    time=models.DateTimeField(auto_now_add=True)
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    



class PersonDetails(models.Model):
    person_id=models.AutoField(primary_key=True)
    person_state=models.CharField(max_length=20)
    person_city=models.CharField(max_length=20)
    person_pincode=models.CharField(max_length=6)
    person_district=models.CharField(max_length=20)
    person_address=models.CharField(max_length=200) 
    person_contact_no=models.BigIntegerField()
    user=models.OneToOneField(User,on_delete=models.CASCADE)
class Product(models.Model):
    product_id=models.AutoField(primary_key=True)
    product_name=models.CharField(max_length=100)
    product_price=models.FloatField()
    product_instock=models.IntegerField()
    
    product_image=models.ImageField()
    def __str__(self):
         return self.product_name
class Product_Desc(models.Model):
   product_desc_id=models.AutoField(primary_key=True)
   info=models.CharField(max_length=100)
   ram=models.CharField(max_length=20)
   storage_type=models.CharField(max_length=100)
   storage_capacity=models.CharField(max_length=20)
   processor_type=models.CharField(max_length=100)
   graphic_types=models.CharField(max_length=100)
   product=models.OneToOneField(Product,on_delete=models.CASCADE)

class UserCart(models.Model):
    uc_id=models.AutoField(primary_key=True)
    quantity=models.IntegerField()
    price=models.FloatField()
    total=models.FloatField()
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)

class Online_Transaction(models.Model):
    
    time=models.CharField(max_length=200)
    status=models.CharField(max_length=100)
    id=models.AutoField(primary_key=True)
    #student_gender=models.CharField(max_length=20,choices=(('male','male'),('female','female')),default='male')
    #order=models.OneToOneField(Orders,on_delete=models.CASCADE,null=True)
    
    transaction_id=models.CharField(max_length=100)
    transaction_type=models.CharField(max_length=100)

class Orders(models.Model):
    order_id=models.BigAutoField(primary_key=True)   
    order_date_time=models.DateTimeField(auto_now_add=True)
    expected_delivery_date=models.DateField()
    promocode=models.CharField(max_length=10)
    transaction=models.ForeignKey(Online_Transaction,on_delete=models.CASCADE,null=True)
    
    price=models.FloatField()
    quantity=models.IntegerField()
    total=models.FloatField()
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    payment_mode=models.CharField(max_length=100,choices=(('pay online','pay online'),('pay on delivery','pay on delivery')),default='pay on delivery')
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    discount_percentage=models.FloatField()
    def __str__(self):
        return "Order Code:"+str(self.order_id)

class Promocode(models.Model):
    id=models.AutoField(primary_key=True)
    Promo_Code=models.CharField(max_length=10)
    discount_percentage=models.FloatField()
    def __str__(self):
        return self.Promo_Code
class PU(models.Model):
    id=models.AutoField(primary_key=True)
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    promocode=models.ForeignKey(Promocode,on_delete=models.CASCADE)

class Order_Status(models.Model):
    sr_no=models.AutoField(primary_key=True)
    status=models.CharField(max_length=100)
    date_time=models.DateTimeField(auto_now_add=True)
    orders=models.ForeignKey(Orders,on_delete=models.CASCADE)
    
@receiver(post_save,sender=Order_Status)
def order_status_created(sender,instance,created,**kwargs):
    order_status_id=instance.sr_no
    #print(instance.orders.order_id)
    o=Order_Status.objects.get(sr_no=order_status_id)
    os=Order_Status.objects.select_related('orders').filter(sr_no=o.sr_no)   
    order=Orders.objects.get(order_id=os[0].orders.order_id)
    product=Product.objects.get(product_id=order.product_id)
    #print(order.user_id)
    user=User.objects.get(id=order.user_id)
    #print(user.email)
    subject="About ",product.product_name +" ,"
    package="your package:"+product.product_name +" ,"
    status="status:"+os[0].status +" ,"
    date_time="time:"+str(os[0].date_time) +" ,"
    msg=package + status+ date_time
    to=user.email
    res=send_mail(subject,msg,settings.EMAIL_HOST_USER,[to])
    #print(res)        

@receiver(post_save,sender=Orders)
def order_created(sender,instance,created,**kwargs):
 if(instance.payment_mode=='pay on delivery'):
    order_id=instance.order_id
    
    #print(instance.orders.order_id)
    o=Orders.objects.get(order_id=order_id)
    order=Orders.objects.select_related('user','product').get(order_id=order_id)   
    product=Product.objects.get(product_id=order.product_id)
    #print(order.user_id)
    user=User.objects.get(id=order.user_id)
    #print(user.email)
    subject="Order Success Fully Placed For:",product.product_name +" "
    Details="Your Orders Details Are:\n"
    package="Prduct:"+product.product_name +" ,\n"
    pmode="Payment_Mode:"+order.payment_mode + " ,\n"
    
    price="Price:Rs."+str(order.price) + " ,\n"
    quantity="Quantity:"+str(order.quantity)+"\n"
    discount="Discount:"+ str(order.discount_percentage) +"%"+",\n"
    promocode="Promocode:"+order.promocode + ",\n"
    total="Total_Bill:Rs."+str(order.total) + ",\n"
    edate="Expected Delivery Date:"+ str(o.expected_delivery_date)+",\n"
    
    msg=Details+package+pmode+price+quantity+discount+promocode+total+edate
    to=user.email
    res=send_mail(subject,msg,settings.EMAIL_HOST_USER,[to])
    