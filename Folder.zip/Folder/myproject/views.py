import hashlib
import hmac
import base64
from datetime import *
#from twilio.rest import Client
from django.conf  import settings
from django.core.mail import send_mail
from datetime import date,timedelta
from django.db.models  import Sum
from django.db import connection
from django.shortcuts import render,redirect,HttpResponse
from django.contrib.auth.models import User,auth
from .models import Product,UserCart,Orders,PersonDetails,Promocode,PU,Otp,Online_Transaction
from django.contrib import messages
import bcrypt
import random
from django.contrib.auth import authenticate
from django.template.context_processors import request
from django.contrib.auth.decorators import login_required
from itertools import product
from django.views.generic.dates import BaseDateDetailView
from django.contrib.auth import  logout
# Create your views here.

def slider(request):
     product=Product.objects.all()
     cart_count=UserCart.objects.filter(user_id=request.user.id).count()
     order_count=Orders.objects.filter(user_id=request.user.id).count()
     
     return render(request,'products.html',{'product':product,'cart_count':cart_count,'order_count':order_count})
@login_required(login_url='login')
def savecart(request):
    if request.method=='POST':
        pid=request.POST['pid']
        quantity=request.POST['quantity']
        if UserCart.objects.filter(product_id=pid,user_id=request.user.id).exists():
            uc=UserCart.objects.get(product_id=pid,user_id=request.user.id)
            newquantity=uc.quantity+int(quantity)
            if(newquantity>5):
                product=Product.objects.get(product_id=pid)
                return render(request,"back.html",{'p':product})
            elif(newquantity<6):
                uc.total=uc.price*newquantity
                uc.quantity=newquantity
                uc.save()
                return redirect("viewcart")

            #p=Product.objects.get(product_id=pid)
            #pn=p.product_name;
        else:
            p=Product.objects.get(product_id=pid)
            price=p.product_price
           
            uc=UserCart()
            uc.product_id=int(pid)
            uc.user_id=request.user.id
            uc.quantity=int(quantity)
            uc.price=price
            uc.total=int(quantity)*price
            uc.save()
            return redirect('viewcart')
            
        return HttpResponse(pid,quantity)
@login_required(login_url='/users/login')

def addcart(request,id):
        product=Product.objects.get(product_id=id)
        cart_count=UserCart.objects.filter(user_id=request.user.id).count()
        order_count=Orders.objects.filter(user_id=request.user.id).count()
   
        return render(request,'CartForm.html',{'id':id,'p':product,'cart_count':cart_count,'order_count':order_count})
'''
def sms(request):
    client=Client(settings.TWILIO_ACCOUNT_SID,settings.TWILIO_AUTH_TOKEN)
    client.messages.create(to=+919511209847,from_=settings.TWILIO_NUMBER,body=("Hi"))
    return HttpResponse("Sent")
'''
def logout_view(request):
    logout(request)
    return render(request,'login.html')

def view(request):
       user=User.objects.get(username=request.user.username)
       id=user.id
       count=UserCart.objects.filter(user_id=id).count()
       print(count)
  
       product=Product.objects.all()
       return render(request,'nav.html',{'product':product,'count':count})
def start(request):
    if request.user.is_authenticated:
       return render(request,"first.html")
    else:
        return render(request,"sec.html")
def viewcart(request):
    #print((date.today()+timedelta(days=30)).isoformat())
    user=User.objects.get(username=request.user.username)
    
    list=UserCart.objects.select_related('user','product').filter(user_id=user.id)
    
    total=UserCart.objects.filter(user_id=user.id).aggregate(Sum('total'))
    cart_count=UserCart.objects.filter(user_id=request.user.id).count()
    order_count=Orders.objects.filter(user_id=request.user.id).count()
   
    #id=user.id
    #q=0UserCart.objects.filter(user_id=id)
    #s=str(q.query)
    
    return render(request,'cart.html',{'list':list,'total':total,'cart_count':cart_count,'order_count':order_count})
def resend(request):
 if request.method== 'POST':
     val=request.POST['val']
    
     user=User.objects.get(id=int(val))
     o=Otp.objects.get(user_id=user.id)
     o.delete()
     c=str(random.randint(1000,9999))
     subject="Verify Your OTP"
     msg="Hi  Please Verify Your Email Your OTP IS:   "+ c +  "  Valid For 1 minute only"
     to=user.email
     res=send_mail(subject,msg,settings.EMAIL_HOST_USER,[to])
     salt=bcrypt.gensalt()
     ot=Otp()
     ot.code=bcrypt.hashpw(c.encode('utf-8'),salt)
     ot.user=user
     ot.save()
     messages.info(request,"OTP Resend Successfully Please Check Your Email")

     return render(request,'verifyuser.html',{'id':user.id})
 else:
      return HttpResponse("Fori")
                 


 
def verifyotp(request):
    if request.method=='POST':
        val=request.POST['val']
        code=request.POST['code']
        user=User.objects.get(id=int(val))
        current=datetime.now()
        print(val)
        o=Otp.objects.get(user_id=int(val))

        print(o.time)
        print(current-o.time)
        print(current.minute-o.time.minute)
        if(bcrypt.checkpw(code.encode('utf-8'),o.code)): 
            if((current.minute-o.time.minute)>1):
              messages.info(request,"OTP Is Expired Please Click Resend")
              return render(request,'verifyuser.html',{'id':user.id})
            else:
                user.is_active=True
                user.save()
                Otp.objects.get(user_id=int(val)).delete()
                
                messages.info(request,"OTP Verified You Can Login Now")
                return render(request,'login.html')
        else:
             messages.info(request,"Invalid OTP")
             return render(request,'verifyuser.html',{'id':user.id})
            





        
    else:
        return HttpResponse("Fori")    
from django.views.decorators.csrf import csrf_exempt
@csrf_exempt
def notify(request):
    print("success")
@csrf_exempt
def returnurl(request):
    #user=User.objects.get(username=request.user.username)
    postData = {
        "orderId": request.POST['orderId'],
        "orderAmount": request.POST['orderAmount'],
        "referenceId": request.POST['referenceId'],
        "txStatus": request.POST['txStatus'],
        "paymentMode": request.POST['paymentMode'],
        "txMsg": request.POST['txMsg'],
        "signature": request.POST['signature'],
        "txTime": request.POST['txTime']

    }

    signatureData = ""
    signatureData = postData['orderId'] + postData['orderAmount'] + postData['referenceId'] + postData['txStatus'] + postData['paymentMode'] + postData['txMsg'] + postData['txTime']

    message = signatureData.encode('utf-8')
    # get secret key from your config
    secret = settings.CASHFREE_CONFIG.get('key').encode('utf-8')
    cs = base64.b64encode(hmac.new(secret, message, digestmod=hashlib.sha256).digest()).decode('utf-8')
    print(cs)
    print(postData.get('signature'))
    if(request.POST['txStatus']=='SUCCESS'):
     if(postData.get('signature')==cs):
      pt=Online_Transaction()
      pt.transaction_id=postData['referenceId']
      pt.time=postData['txTime']
      pt.status='SUCCESS'
      pt.transaction_type=request.POST['paymentMode']
      pt.save()
      o=Orders.objects.get(order_id=int(postData['orderId']))
      o.transaction=pt
      o.save()
      order=Orders.objects.select_related('user','product','transaction').get(order_id=o.order_id)
      quantity="Quantity:"+str(order.quantity)+"\n"
      subject="Order Status:",order.transaction.status +" "
      Details="Your Orders Details Are:\n"
     
      package="Prduct:"+order.product.product_name +" ,\n"
      pmode="Payment_Mode:"+order.payment_mode + " ,\n"
      tid="Transaction Id:"+ order.transaction.transaction_id + " ,\n"
      typep="Transaction Type:"+order.transaction.transaction_type + " ,\n"
    
      price="Price:Rs."+str(order.price) + " ,\n"
      discount="Discount:"+ str(order.discount_percentage) +"%"+",\n"
      promocode="Promocode:"+order.promocode + ",\n"
      total="Total_Bill:Rs."+str(order.total) + ",\n"
      edate="Expected Delivery Date:"+ str(o.expected_delivery_date)+",\n"
      msg=Details+package+pmode+tid+typep+price+quantity+discount+promocode+total+edate
      to=order.user.email
      res=send_mail(subject,msg,settings.EMAIL_HOST_USER,[to])

    
      return render(request,'return.html',{"message":'Thank You,payment successfully Done'})

     else:
      pt=Online_Transaction()
      pt.transaction_id=postData['referenceId']
      pt.time=postData['txTime']
      pt.status='Unauthorised Error'
      pt.transaction_type=request.POST['paymentMode']
      pt.save()
      o=Orders.objects.get(order_id=int(postData['orderId']))
      o.transaction=pt
      o.save()
      order=Orders.objects.select_related('user','product','transaction').get(order_id=o.order_id)
      if(order.promocode!='-'):
       pr=Promocode.objects.get(Promo_Code=order.promocode)
       promous=PU.objects.get(promocode=pr,user=uorder.user)
       promous.delete()
      quantity="Quantity:"+str(order.quantity)+"\n"
      subject="Order Status:",order.transaction.status +" "
      Details="Your Orders Details Are:\n"
    
      package="Prduct:"+order.product.product_name +" ,\n"
      pmode="Payment_Mode:"+order.payment_mode + " ,\n"
      tid="Transaction Id:"+ order.transaction.transaction_id + " ,\n"
      typep="Transaction Type:"+order.transaction.transaction_type + " ,\n"
    
      price="Price:Rs."+str(order.price) + " ,\n"
      discount="Discount:"+ str(order.discount_percentage) +"%"+",\n"
      promocode="Promocode:"+order.promocode + ",\n"
      total="Total_Bill:Rs."+str(order.total) + ",\n"
      #edate="Expected Delivery Date:"+ str(o.expected_delivery_date)+",\n"
      msg=Details+package+pmode+tid+typep+price+quantity+discount+promocode+total#+edate
      to=order.user.email
      res=send_mail(subject,msg,settings.EMAIL_HOST_USER,[to])

      return render(request,'return.html',{"message":'Something Getting Wrong Please Call Customer Care'})
  
    elif(request.POST['txStatus']=='CANCELLED'):
      pt=Online_Transaction()
      pt.transaction_id=postData['referenceId']
      pt.time=postData['txTime']
      pt.status=request.POST['txStatus']
      pt.transaction_type=request.POST['paymentMode']
      pt.save()
      o=Orders.objects.get(order_id=int(postData['orderId']))
      o.transaction=pt
      o.save()
      order=Orders.objects.select_related('user','product','transaction').get(order_id=o.order_id)
      if(order.promocode!='-'):
       pr=Promocode.objects.get(Promo_Code=order.promocode)
       promous=PU.objects.get(promocode=pr,user=uorder.user)
       promous.delete()
      
      quantity="Quantity:"+str(order.quantity)+"\n"
      subject="Order Status:",order.transaction.status +" "
      Details="Your Orders Details Are:\n"
    
      package="Prduct:"+order.product.product_name +" ,\n"
      pmode="Payment_Mode:"+order.payment_mode + " ,\n"
      tid="Transaction Id:"+ order.transaction.transaction_id + " ,\n"
      typep="Transaction Type:"+order.transaction.transaction_type + " ,\n"
    
      price="Price:Rs."+str(order.price) + " ,\n"
      discount="Discount:"+ str(order.discount_percentage) +"%"+",\n"
      promocode="Promocode:"+order.promocode + ",\n"
      total="Total_Bill:Rs."+str(order.total) + ",\n"
      #edate="Expected Delivery Date:"+ str(o.expected_delivery_date)+",\n"
      msg=Details+package+pmode+tid+typep+price+quantity+discount+promocode+total#+#edate
      to=order.user.email
      res=send_mail(subject,msg,settings.EMAIL_HOST_USER,[to])
      
      return render(request,'return.html',{"message":'You Cancelled the order'})

    elif(request.POST['txStatus']=='PENDING'):
      pt=Online_Transaction()
      pt.transaction_id=postData['referenceId']
      pt.time=postData['txTime']
      pt.status=request.POST['txStatus']
      pt.transaction_type=request.POST['paymentMode']
      pt.save()
      o=Orders.objects.get(order_id=int(postData['orderId']))
      o.transaction=pt
      o.save()
      order=Orders.objects.select_related('user','product','transaction').get(order_id=o.order_id)
      quantity="Quantity:"+str(order.quantity)+"\n"
      subject="Order Status:",order.transaction.status +" "
      Details="Your Orders Details Are:\n"
      if(order.promocode!='-'):
       pr=Promocode.objects.get(Promo_Code=order.promocode)
       promous=PU.objects.get(promocode=pr,user=uorder.user)
       promous.delete()
      
      package="Prduct:"+order.product.product_name +" ,\n"
      pmode="Payment_Mode:"+order.payment_mode + " ,\n"
      tid="Transaction Id:"+ order.transaction.transaction_id + " ,\n"
      typep="Transaction Type:"+order.transaction.transaction_type + " ,\n"
    
      price="Price:Rs."+str(order.price) + " ,\n"
      discount="Discount:"+ str(order.discount_percentage) +"%"+",\n"
      promocode="Promocode:"+order.promocode + ",\n"
      total="Total_Bill:Rs."+str(order.total) + ",\n"
      edate="Expected Delivery Date:"+ str(o.expected_delivery_date)+",\n"
      msg=Details+package+pmode+tid+typep+price+quantity+discount+promocode+total#+edate
      to=order.user.email
      res=send_mail(subject,msg,settings.EMAIL_HOST_USER,[to])

      return render(request,'return.html',{"message":'Your Payment Is Pending We Will Respond you shortley'})
    elif(request.POST['txStatus']=='FAILED'):
      pt=Online_Transaction()
      pt.transaction_id=postData['referenceId']
      pt.time=postData['txTime']
      pt.status=request.POST['txStatus']
      pt.transaction_type=request.POST['paymentMode']
      pt.save()
      o=Orders.objects.get(order_id=int(postData['orderId']))
      o.transaction=pt
      o.save()
      order=Orders.objects.select_related('user','product','transaction').get(order_id=o.order_id)
      if(order.promocode!='-'):
       pr=Promocode.objects.get(Promo_Code=order.promocode)
       promous=PU.objects.get(promocode=pr,user=uorder.user)
       promous.delete()
      
      quantity="Quantity:"+str(order.quantity)+"\n"
      subject="Order Status:",order.transaction.status +" "
      Details="Your Orders Details Are:\n"
    
      package="Prduct:"+order.product.product_name +" ,\n"
      pmode="Payment_Mode:"+order.payment_mode + " ,\n"
      tid="Transaction Id:"+ order.transaction.transaction_id + " ,\n"
      typep="Transaction Type:"+order.transaction.transaction_type + " ,\n"
    
      price="Price:Rs."+str(order.price) + " ,\n"
      discount="Discount:"+ str(order.discount_percentage) +"%"+",\n"
      promocode="Promocode:"+order.promocode + ",\n"
      total="Total_Bill:Rs."+str(order.total) + ",\n"
      edate="Expected Delivery Date:"+ str(o.expected_delivery_date)+",\n"
      msg=Details+package+pmode+tid+typep+price+quantity+discount+promocode+total#+edate
      to=order.user.email
      res=send_mail(subject,msg,settings.EMAIL_HOST_USER,[to])

      return render(request,'return.html',{"message":'Payment Failed'})

            
@csrf_exempt
def saveorder(request):
 if request.method=='POST':
    user=User.objects.get(username=request.user.username)
    pd=PersonDetails.objects.filter(user=user)
    state=request.POST['state']
    city=request.POST['city']
    district=request.POST['district']
    pincode=int(request.POST['pincode'])
    address=request.POST['address']
    contact=int(request.POST['cno'])
    total=UserCart.objects.filter(user_id=user.id).aggregate(Sum('total'))
    id=request.POST['id']
    #t=total.total__sum
   
    if len(request.POST['pc'])==0:
     if len(pd)==0:
        
        print("N")
        p=PersonDetails()
        p.user=user
        p.person_state=state
        p.person_city=city
        p.person_district=district
        p.person_pincode=pincode
        p.person_address=address
        p.person_contact_no=contact
        p.save()
     else:
        print("Y")
        pd[0].user=user
        pd[0].person_state=state
        pd[0].person_city=city
        pd[0].person_district=district
        pd[0].person_pincode=pincode
        pd[0].person_address=address
        pd[0].person_contact_no=contact
        pd[0].save()
     p=UserCart.objects.select_related('user','product').get(uc_id=int(id))
    
     payment_mode=request.POST['ot']
     edate=(date.today()+timedelta(days=7)).isoformat()
     if(payment_mode=='pay on delivery'):
        o=Orders()
        o.expected_delivery_date=edate
        o.price=p.price
        o.payment_mode=payment_mode
        o.quantity=p.quantity
        o.total=p.total
        o.promocode="-"
        o.product=p.product
        o.discount_percentage=0
        o.user=user
        #print(o.product)
        #print(o.order_id)
        o.save()
        print(o.order_id)
        UserCart.objects.get(uc_id=int(id)).delete()
        cart_count=UserCart.objects.filter(user_id=request.user.id).count()
        order_count=Orders.objects.filter(user_id=request.user.id).count()
        order=Orders.objects.select_related('user','product').get(order_id=o.order_id)
        return render(request,'ordersuccess.html',{'o':order,'order_count':order_count,'cart_count':+cart_count})
     else:
         o=Orders()
         o.expected_delivery_date=edate
         o.price=p.price
         o.quantity=p.quantity
         o.payment_mode=payment_mode
         o.total=p.total
         o.promocode="-"
         o.product=p.product
         o.discount_percentage=0
         o.user=user
         o.save()
         config=settings.CASHFREE_CONFIG

         postData={
           "appId": config.get('id'),
           "orderId":o.order_id ,
           "orderAmount": o.total,
           "customerName": user.first_name +" " + user.last_name,
           "customerPhone": PersonDetails.objects.get(user_id=user.id).person_contact_no,
           "customerEmail":user.email,
           "returnUrl": 'http://127.0.0.1:8000/users/return',
           "notifyUrl": 'http://127.0.0.1:8000/users/notify'
         }
         sortedKeys = sorted(postData)
       #print(sortedKeys)
         url = "https://test.cashfree.com/billpay/checkout/post/submit"
         signatureData = ""
         for key in sortedKeys:
           signatureData += str(key) + str(postData[key])

         message = signatureData.encode('utf-8')
       # get secret key from your config
         secret = config.get('key').encode('utf-8')
         signature = base64.b64encode(hmac.new(secret, message, digestmod=hashlib.sha256).digest()).decode("utf-8")
         UserCart.objects.get(uc_id=int(id)).delete()
         return render(request,'payment.html', {"postData":postData, "signature":signature, "url":url})

       #print(signature)
         #mode='TEST'
       #if mode == 'PROD':
          
       #else:
           #url = "https://test.cashfree.com/billpay/checkout/post/submit"
          
    
    else:  
      pc=request.POST['pc']
      if(Promocode.objects.filter(Promo_Code=pc).exists()):
          if(pc=='FIRST'):
              if(Orders.objects.filter(user=user).count()>0):
                  messages.info(request,"This Promocode Applicable For First Order Only")
                  return redirect('addorder',id=id)
              else:
                  discount_percentage=Promocode.objects.get(Promo_Code=pc).discount_percentage
                  promocode=Promocode.objects.get(Promo_Code=pc)
                  #count=UserCart.objects.filter(user=user).count()
                  pu=PU()
                  pu.promocode=promocode
                  pu.user=user
                  pu.save()
                  if len(pd)==0:
        
                    print("N")
                    p=PersonDetails()
                    p.user=user
                    p.person_state=state
                    p.person_city=city
                    p.person_district=district
                    p.person_pincode=pincode
                    p.person_address=address
                    p.person_contact_no=contact
                    p.save()
                  else:
                    print("Y")
                    pd[0].user=user
                    pd[0].person_state=state
                    pd[0].person_city=city
                    pd[0].person_district=district
                    pd[0].person_pincode=pincode
                    pd[0].person_address=address
                    pd[0].person_contact_no=contact
                    pd[0].save()
                  p=UserCart.objects.select_related('user','product').get(uc_id=int(id))
                  payment_mode=request.POST['ot']
                  edate=(date.today()+timedelta(days=7)).isoformat()
                  if(payment_mode!='pay online'):
                      o=Orders()
                      o.expected_delivery_date=edate
                      o.price=p.price
                      o.quantity=p.quantity
                      o.total=p.total-p.total*discount_percentage/100
                      o.promocode=promocode.Promo_Code
                      o.product=p.product
                      o.discount_percentage=discount_percentage
                      o.user=user
        #print(o.product)
                      o.save()
                      UserCart.objects.get(uc_id=int(id)).delete()
                      cart_count=UserCart.objects.filter(user_id=request.user.id).count()
                      order_count=Orders.objects.filter(user_id=request.user.id).count()
                      order=Orders.objects.select_related('user','product').get(order_id=o.order_id)
                      return render(request,'ordersuccess.html',{'o':order,'order_count':order_count,'cart_count':+cart_count})
                  else:
                    
                      o=Orders()
                      o.expected_delivery_date=edate
                      o.price=p.price
                      o.quantity=p.quantity
                      o.payment_mode=payment_mode
                      o.total=p.total-p.total*discount_percentage/100

                      o.promocode=promocode.Promo_Code
                      o.product=p.product
                      o.discount_percentage=discount_percentage
                      o.user=user
                      o.save()
                      config=settings.CASHFREE_CONFIG
                      postData={
                      "appId": config.get('id'),
                      "orderId":o.order_id ,
                      "orderAmount": o.total,
                      "customerName": user.first_name +" " + user.last_name,
                      "customerPhone": PersonDetails.objects.get(user_id=user.id).person_contact_no,
                      "customerEmail":user.email,
                      "returnUrl": 'http://127.0.0.1:8000/users/return',
                      "notifyUrl": 'http://127.0.0.1:8000/users/notify'
         }
                      sortedKeys = sorted(postData)
       #print(sortedKeys)
                      url = "https://test.cashfree.com/billpay/checkout/post/submit"
                      signatureData = ""
                      for key in sortedKeys:
                         signatureData += str(key) + str(postData[key])

                      message = signatureData.encode('utf-8')
       # get secret key from your config
                      secret = config.get('key').encode('utf-8')
                      signature = base64.b64encode(hmac.new(secret, message, digestmod=hashlib.sha256).digest()).decode("utf-8")
                      UserCart.objects.get(uc_id=int(id)).delete()
                      return render(request,'payment.html', {"postData":postData, "signature":signature, "url":url})

     

          else:
              promocode=Promocode.objects.get(Promo_Code=pc)
              
              if(PU.objects.filter(user=user ,promocode=promocode).exists()):
                  messages.info(request,"This PromoCode Already Used")
                  return redirect('addorder',id=id)
              else:
                  discount_percentage=Promocode.objects.get(Promo_Code=pc).discount_percentage
                  #count=UserCart.objects.filter(user=user).count()
                  pu=PU()
                  pu.promocode=promocode
                  pu.user=user
                  pu.save()
                  if len(pd)==0:
        
                    print("N")
                    p=PersonDetails()
                    p.user=user
                    p.person_state=state
                    p.person_city=city
                    p.person_district=district
                    p.person_pincode=pincode
                    p.person_address=address
                    p.person_contact_no=contact
                    p.save()
                  else:
                    print("Y")
                    pd[0].user=user
                    pd[0].person_state=state
                    pd[0].person_city=city
                    pd[0].person_district=district
                    pd[0].person_pincode=pincode
                    pd[0].person_address=address
                    pd[0].person_contact_no=contact
                    pd[0].save()
                  p=UserCart.objects.select_related('user','product').get(uc_id=int(id))
                  payment_mode=request.POST['ot']
                  edate=(date.today()+timedelta(days=7)).isoformat()
                  if(payment_mode!='pay online'):
                     o=Orders()
                     o.expected_delivery_date=edate
                     o.price=p.price
                     o.quantity=p.quantity
                     o.promocode=promocode.Promo_Code
                 
                     o.total=p.total-p.total*discount_percentage/100
                     o.product=p.product
                     o.discount_percentage=discount_percentage
                     o.user=user
        #print(o.product)
                     o.save()
                     UserCart.objects.get(uc_id=int(id)).delete()
                     cart_count=UserCart.objects.filter(user_id=request.user.id).count()
                     order_count=Orders.objects.filter(user_id=request.user.id).count()
                     order=Orders.objects.select_related('user','product').get(order_id=o.order_id)
                     return render(request,'ordersuccess.html',{'o':order,'order_count':order_count,'cart_count':+cart_count})
                  else:
                    
                      o=Orders()
                      o.expected_delivery_date=edate
                      o.price=p.price
                      o.quantity=p.quantity
                      o.payment_mode=payment_mode
                      o.total=p.total-p.total*discount_percentage/100

                      o.promocode=promocode.Promo_Code
                      o.product=p.product
                      o.discount_percentage=discount_percentage
                      o.user=user
                      o.save()
                      config=settings.CASHFREE_CONFIG
                      postData={
                      "appId": config.get('id'),
                      "orderId":o.order_id ,
                      "orderAmount": o.total,
                      "customerName": user.first_name +" " + user.last_name,
                      "customerPhone": PersonDetails.objects.get(user_id=user.id).person_contact_no,
                      "customerEmail":user.email,
                      "returnUrl": 'http://127.0.0.1:8000/users/return',
                      "notifyUrl": 'http://127.0.0.1:8000/users/notify'
         }
                      sortedKeys = sorted(postData)
       #print(sortedKeys)
                      url = "https://test.cashfree.com/billpay/checkout/post/submit"
                      signatureData = ""
                      for key in sortedKeys:
                         signatureData += str(key) + str(postData[key])

                      message = signatureData.encode('utf-8')
       # get secret key from your config
                      secret = config.get('key').encode('utf-8')
                      signature = base64.b64encode(hmac.new(secret, message, digestmod=hashlib.sha256).digest()).decode("utf-8")
                      UserCart.objects.get(uc_id=int(id)).delete()
                      return render(request,'payment.html', {"postData":postData, "signature":signature, "url":url})

     

     
      else:
          messages.info(request,'Invalid Promocode')
          return redirect('addorder',id=id)
                  


  
    
        
        
def vieworders(request):
    order=Orders.objects.select_related('user','product').filter(user=request.user)
    cart_count=UserCart.objects.filter(user_id=request.user.id).count()
    order_count=Orders.objects.filter(user_id=request.user.id).count()
    return render(request,'vieworders.html',{'list':order,'cart_count':cart_count,'order_count':order_count})

def navigation(request):
       user=User.objects.get(username='omkarbhosale321@gmail.com')
       id=user.id
       count=UserCart.objects.filter(user_id=id).count()
       print(count)
  
       return render(request,'nav.html',{'count':count})

def navigation2(request):
       return render(request,'nav2.html')

@login_required(login_url='login')
def home(request):
    return HttpResponse("Welcome:"+request.user.username)
def login(request):
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        next=request.POST['next']
        print("This is next:",next)
               
        user=auth.authenticate(username=username,password=password)
        if user is not  None :
         if(user.is_active==True):
            auth.login(request,user)
            if len(next)==0:
                return redirect('slide')
            else:
                 return redirect(next)
         else:
            messages.info(request,"Please Verify Your Account")
            return render(request,'verifyuser.html',{'id':user.id})
        else:
            messages.info(request, "Invalid Login Details")
            return render(request,'login.html')
                 
    else:
        
        return render(request,'login.html')

def email(request):
           subject="Demo Django Mail"
           msg="Hi Omkar"
           to="omkarbhosale1998@gmail.com"
           res=send_mail(subject,msg,settings.EMAIL_HOST_USER,[to])
           return HttpResponse(res)

def form(request):
    return render(request, 'form.html')
def index(request):

    return render(request,'index.html')
@login_required(login_url='/users/login')
def addorder(request,id):
        user=request.user
        pd=PersonDetails.objects.filter(user_id=request.user.id)
        #total=UserCart.objects.filter(user_id=user.id).aggregate(Sum('total'))
        #t=total
    
        cart_count=UserCart.objects.filter(user_id=request.user.id).count()
        order_count=Orders.objects.filter(user_id=request.user.id).count()
        
        #return HttpResponse(str(id))
        uc=UserCart.objects.get(uc_id=id)
        if(uc.user==user):
          return render(request,'orderpage.html',{'uc':uc,'person':pd,'order_count':order_count,'cart_count':cart_count,'id':id})
        else:
            return HttpResponse("You Are Not Authorised To View This Page")


@login_required(login_url='/users/login')
def deletecart(request,id):
        user=request.user
        #pd=PersonDetails.objects.filter(user_id=request.user.id)
        #total=UserCart.objects.filter(user_id=user.id).aggregate(Sum('total'))
        #t=total
    
        cart_count=UserCart.objects.filter(user_id=request.user.id).count()
        order_count=Orders.objects.filter(user_id=request.user.id).count()
        
        #return HttpResponse(str(id))
        uc=UserCart.objects.get(uc_id=id)
        if(uc.user==user):
          UserCart.objects.get(uc_id=id).delete()
          return redirect('viewcart')
        else:
            return HttpResponse("You Are Not Authorised To View This Page")







def save(request):
    if request.method=='POST':
        username = request.POST['email']
        email=request.POST['email']
        password=request.POST['pass']
        confirm=request.POST['pass2']
        first_name=request.POST['fn']
        last_name=request.POST['ln']
        if password==confirm:
              if User.objects.filter(email=email).exists():
                  messages.info(request, "Email Already Taken Please Use Different Email")
                  return render(request,'index.html')

              else:
                  
                  user=User.objects.create_user(username=username,email=email,password=password,first_name=first_name,last_name=last_name,is_active=False)
                  user.save()
                  messages.info(request,"Please Verify Your Email")
                  print(user.id)
                  o=Otp()
                  o.user=user

                  c=str(random.randint(1000,9999))
                  subject="Please Verify Your OTP"
                  msg="Hi Please Verify Your Email Your OTP IS:  "+ c + "  Valid For 1 minute only"
                  to=user.email
                  res=send_mail(subject,msg,settings.EMAIL_HOST_USER,[to])
          
                  salt=bcrypt.gensalt()
                 
                  #o.code=bcrypt.hashpw(c.encode('utf-8'),salt)
                  o.code=bcrypt.hashpw(c.encode('utf-8'),salt)
                  if bcrypt.checkpw(c.encode('utf-8'),o.code):
                        print('true')
                  else:
                      print('false')
                  o.save()
                  #print(uid)
                  
                  return render(request,'verifyuser.html',{'id':user.id})


        else:
               messages.info(request,"Password Not Match")
               return render(request,'index.html')

    else:
        return render(request,'index.html')